/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.act2;

/**
 *
 * @author garci
 */
class Proceso {
    String nombre;
    int tamano;

    public Proceso(String nombre, int tamano) {
        this.nombre = nombre;
        this.tamano = tamano;
    }
}